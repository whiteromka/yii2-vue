<?php

class Cat
{
    public $name = 'Forest';

    public function sayMyay()
    {
        echo 'Mey';
    }
}

function sayHi()
{
    echo 'Hi bro';
}

sayHi();

$cat = new Cat();
$cat->sayMyay();


// PHP
// variable $a                              //0     3
// types  'sdsadsad' 1   1.2    true/false   [1,2,3,4]  ['a' => 1,  'b' => 2]
// cycles: for(), foreach()

// custom functions

// language functions():
    // echo
    // var_dump print_r
    // massive:
        // count(), array_shift(), array_pop(), array_key_exists(), epmty(), array_keys(), array_values(), implode()

    // string:
        // str_replace(), strpos(), explode()

// Class
// Oject


// js
// variable
// types
// cycles: for, for in, foreach?

// custom functions
// Oject

//let cat = {
//    name: 'Forest',
//    function sayMya() {
//        console.log('Maya')
//    }
//}




