<template>
    <div>
      <h1>!!!!!!</h1>
      <h2>fgdgd</h2>
    </div>
</template>

<script>
export default {
  name: 'TestComponent'
}
</script>

<style scoped>
h1 {
  cursor: pointer;
  margin: 40px 0 0;
}
</style>
