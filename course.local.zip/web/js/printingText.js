// let text = "PHP, JS, SQL, Yii2, Vue, Jquery ";
// let delay = 100; // Скорость печатания
// let elem = document.getElementById("jjj"); // id элемента для вывода результата
// //let elem = document.getElementById('elem');
//
// let printText = function(text, elem, delay) {
//     console.log(text)
//     console.log(elem)
//     console.log(delay)
//     if(text.length > 0) {
//         elem.innerHTML += text[0];
//         setTimeout(
//             function() {
//                 printText(text.slice(1), elem, delay);
//             }, delay
//         );
//     }
// }
// printText(text, elem, delay);