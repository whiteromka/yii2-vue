 ### установить vue cli
 npm install -g @vue/cli
 vue create my-project

 ### vue запуск
 cd vue
 npm run serve // режим разработки
 npm run build // продакшен сборка
